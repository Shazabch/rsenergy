@extends('layouts.main')
@section('content')
<div class="card card-body mt-4">
<livewire:employee-table/>
</div>
@endsection