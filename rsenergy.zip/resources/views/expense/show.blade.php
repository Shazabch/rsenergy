@extends('layouts.main')

@section('content')
<div class="card mt-4">
    <div class="card-body">
    <livewire:expense-table/>
    </div>
</div>
@endsection