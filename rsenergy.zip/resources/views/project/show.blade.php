@extends('layouts.main')
@section('content')

<div class="card card-body mt-4" style="z-index: 7;">
<livewire:project-table/>
</div>
@endsection