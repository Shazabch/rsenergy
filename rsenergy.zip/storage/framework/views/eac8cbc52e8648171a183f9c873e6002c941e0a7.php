
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card card-body mt-4">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('project-payment-table', ['type' => ''.e($projects->id).''])->html();
} elseif ($_instance->childHasBeenRendered('Oo6RoP6')) {
    $componentId = $_instance->getRenderedChildComponentId('Oo6RoP6');
    $componentTag = $_instance->getRenderedChildComponentTagName('Oo6RoP6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Oo6RoP6');
} else {
    $response = \Livewire\Livewire::mount('project-payment-table', ['type' => ''.e($projects->id).'']);
    $html = $response->html();
    $_instance->logRenderedChild('Oo6RoP6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-body mt-4">
            <div class="row">
                <h4 class="text-italic text-center">Add New Payment</h4>
                <hr>
            </div>
            <form action="<?php echo e(route('projectpayment.store',$projects->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <label for="amount">Add Amount</label>
                    <input type="text" class="form-control" name="amount">
                </div>
                
            </div>
            <div class="row">
            <div class="col mt-3">
                    <button class="btn btn-success text-white" type="submit">Add Payment</button>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/projectPayment/add.blade.php ENDPATH**/ ?>