
    
<?php $__env->startSection('content'); ?>
<div class="card mt-3">
    <div class="card-body">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('inventory-table', [])->html();
} elseif ($_instance->childHasBeenRendered('g0VO2fb')) {
    $componentId = $_instance->getRenderedChildComponentId('g0VO2fb');
    $componentTag = $_instance->getRenderedChildComponentTagName('g0VO2fb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('g0VO2fb');
} else {
    $response = \Livewire\Livewire::mount('inventory-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('g0VO2fb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/inventory/show.blade.php ENDPATH**/ ?>