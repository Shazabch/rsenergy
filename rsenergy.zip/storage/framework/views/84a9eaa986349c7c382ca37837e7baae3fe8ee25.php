
<?php $__env->startSection('content'); ?>
<div class="row  mt-4">
    <div class="col-md-8">
        <div class="card card-body">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pcategory-table', [])->html();
} elseif ($_instance->childHasBeenRendered('KDQs6AC')) {
    $componentId = $_instance->getRenderedChildComponentId('KDQs6AC');
    $componentTag = $_instance->getRenderedChildComponentTagName('KDQs6AC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KDQs6AC');
} else {
    $response = \Livewire\Livewire::mount('pcategory-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('KDQs6AC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-body">
            <div class="row">
                <h4 class="text-center text-italic">New Product Category</h4>
                <hr>
            </div>
            <form action="<?php echo e(route('pcategory.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <div class="row mt-3 mb-3" >
                <div class="col-md-12">
                    <label for="name">Category Name</label>
                    <input type="text" name="name" class="form-control">
                </div>
                <div class="row mt-3">
                    <div class="col">
                        <button type="submit" class="btn btn-success text-white">Add Category</button>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/pcategory/add.blade.php ENDPATH**/ ?>