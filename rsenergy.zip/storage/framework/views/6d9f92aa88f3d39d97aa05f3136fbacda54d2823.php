
<?php $__env->startSection('content'); ?>
<div class="row ">
    <div class="col-md-8">
        <div class="card card-body mt-4">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pinventory-table', ['type' => ''.e($projects->id).''])->html();
} elseif ($_instance->childHasBeenRendered('j4dRTKB')) {
    $componentId = $_instance->getRenderedChildComponentId('j4dRTKB');
    $componentTag = $_instance->getRenderedChildComponentTagName('j4dRTKB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('j4dRTKB');
} else {
    $response = \Livewire\Livewire::mount('pinventory-table', ['type' => ''.e($projects->id).'']);
    $html = $response->html();
    $_instance->logRenderedChild('j4dRTKB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-body mt-4">
            <div class="row">
                <h4 class="text-center text-italic">Add Inventory Used</h4>
                <hr>
            </div>
            <form action="<?php echo e(route('pinventory.store',$projects->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row mt-3 mb-3">
                    <div class="col-md-12">
                        <label for="product_id">Select Product</label>
                        <select name="product_id" class="form-control" >
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <label for="quantity" class="mt-2">Quantity</label>
                        <input type="text" class="form-control" name="quantity">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <button class="btn btn-success text-white mt-2" type="submit">Add Item</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/pinventory/add.blade.php ENDPATH**/ ?>