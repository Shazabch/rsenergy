
<?php $__env->startSection('content'); ?>

<div class="card card-body mt-4" style="z-index: 7;">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('project-table', [])->html();
} elseif ($_instance->childHasBeenRendered('lmtdK0i')) {
    $componentId = $_instance->getRenderedChildComponentId('lmtdK0i');
    $componentTag = $_instance->getRenderedChildComponentTagName('lmtdK0i');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lmtdK0i');
} else {
    $response = \Livewire\Livewire::mount('project-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('lmtdK0i', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/project/show.blade.php ENDPATH**/ ?>