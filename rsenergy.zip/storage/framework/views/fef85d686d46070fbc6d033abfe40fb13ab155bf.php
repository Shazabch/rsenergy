

<?php $__env->startSection('content'); ?>
    <div class="row ">
        <div class="col-md-9">
                <div class="card card-body mt-4">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('owner-table', [])->html();
} elseif ($_instance->childHasBeenRendered('qJYiDyp')) {
    $componentId = $_instance->getRenderedChildComponentId('qJYiDyp');
    $componentTag = $_instance->getRenderedChildComponentTagName('qJYiDyp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qJYiDyp');
} else {
    $response = \Livewire\Livewire::mount('owner-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('qJYiDyp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
        </div>
        <div class="col-md-3">
            <div class="card mt-4">
                <div class="card-body">
                    <form action="<?php echo e(route('owner.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <h4 class="text-italic text-center">Add New Owner</h4>
                            <hr>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="name">Name</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-success text-white mt-2" type="submit">Add Owner</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/owner/addnshow.blade.php ENDPATH**/ ?>