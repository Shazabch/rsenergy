
<?php $__env->startSection('content'); ?>
<div class="card card-body mt-4">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('vendor-table', [])->html();
} elseif ($_instance->childHasBeenRendered('5lH1Ags')) {
    $componentId = $_instance->getRenderedChildComponentId('5lH1Ags');
    $componentTag = $_instance->getRenderedChildComponentTagName('5lH1Ags');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5lH1Ags');
} else {
    $response = \Livewire\Livewire::mount('vendor-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('5lH1Ags', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/vendors/show.blade.php ENDPATH**/ ?>