
<?php $__env->startSection('content'); ?>
<div class="card card-body mt-4">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('employee-table', [])->html();
} elseif ($_instance->childHasBeenRendered('RPNiJq7')) {
    $componentId = $_instance->getRenderedChildComponentId('RPNiJq7');
    $componentTag = $_instance->getRenderedChildComponentTagName('RPNiJq7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RPNiJq7');
} else {
    $response = \Livewire\Livewire::mount('employee-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('RPNiJq7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/employee/show.blade.php ENDPATH**/ ?>