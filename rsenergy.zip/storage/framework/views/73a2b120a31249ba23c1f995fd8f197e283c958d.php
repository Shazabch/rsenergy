

<?php $__env->startSection('content'); ?>
<div class="card card-body mt-4">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('expense-category-table', [])->html();
} elseif ($_instance->childHasBeenRendered('e9J2Hs5')) {
    $componentId = $_instance->getRenderedChildComponentId('e9J2Hs5');
    $componentTag = $_instance->getRenderedChildComponentTagName('e9J2Hs5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('e9J2Hs5');
} else {
    $response = \Livewire\Livewire::mount('expense-category-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('e9J2Hs5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/category/show.blade.php ENDPATH**/ ?>