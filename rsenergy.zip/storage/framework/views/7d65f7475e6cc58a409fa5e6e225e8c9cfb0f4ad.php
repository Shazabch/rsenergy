
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
   <div class="col-md-8 mt-4">
   <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('inventory.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h4 class="text-center mb-4">Add Inventory Item Here</h4>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="date">Date</label>
                            <input class="form-control" type="date" name="date" placeholder="Click to Add">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="date">Product</label>
                            <input class="form-control" type="text" name="product" placeholder="Product Name Here">
                         </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="date">Brand</label>
                            <input class="form-control" type="text" name="brand" placeholder="Brand Name Here">
                         </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="date">Unit Price</label>
                            <input class="form-control" type="number" name="brand" placeholder="Unit Price">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                         <div class="mb-3">
                            <label for="date">Unit Type</label>
                            <select name="" class="form-control">
                                <option value="">Per Piece</option>
                                <option value="">Per Pair</option>
                                <option value="">Per Box</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="date">QTY</label>
                            <input class="form-control" type="number" name="qty" placeholder="Quantity">
                        </div>
                    </div>
                </div>
                
                <div class="row justify-content-center">
                    <div class="col-md-3">

                    </div>
                </div>
                

                
                
                

            </form>
        </div>
    </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/inventory/add.blade.php ENDPATH**/ ?>