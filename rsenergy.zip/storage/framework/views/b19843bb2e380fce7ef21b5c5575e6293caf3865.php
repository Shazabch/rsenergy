

<?php $__env->startSection('content'); ?>
<div class="card mt-4">
    <div class="card-body">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('expense-table', [])->html();
} elseif ($_instance->childHasBeenRendered('lJioYkX')) {
    $componentId = $_instance->getRenderedChildComponentId('lJioYkX');
    $componentTag = $_instance->getRenderedChildComponentTagName('lJioYkX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lJioYkX');
} else {
    $response = \Livewire\Livewire::mount('expense-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('lJioYkX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/expense/show.blade.php ENDPATH**/ ?>