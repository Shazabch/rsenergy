
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mt-4">
    <div class="col-md-7">
        <div class="card card-body">
            <div class="row">
                <h4 class="text-center text-italic">Add New Purchase</h4>
                <hr>
            </div>
            <form action="<?php echo e(route('purchase.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row mt-3 mb-3">
                <div class="col-md-6">
                    <label for="product_id">Product ID</label>
                    <select class="form-control" name="product_id" >
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="unit_price">Unit Price</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['unit_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="unit_price">
                </div>
            </div>
            <div class="row mt-3 mb-3">
                <div class="col-md-6">
                    <label for="quantity">Quantity</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qunatity">
                </div>
                <div class="col-md-6">
                    <label for="date">Add Date</label>
                    <input type="date" class="form-control" name="date">
                </div>
            </div>
            <div class="row">
                 <div class="col-md-6">
                    <label for="vendor_id">Vendor ID</label>
                    <select class="form-control" name="vendor_id" >
                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->name); ?></option>     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>
                 <div class="col-md-6">
                     <button class="btn btn-success mt-4 text-white" type="submit">Add Purchase</button>
                 </div>
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/purchase/add.blade.php ENDPATH**/ ?>