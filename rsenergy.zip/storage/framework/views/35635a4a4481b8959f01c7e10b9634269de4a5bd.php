
<?php $__env->startSection('content'); ?>
<div class="card card-body mt-4">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pcategory-table', [])->html();
} elseif ($_instance->childHasBeenRendered('MiXY2hl')) {
    $componentId = $_instance->getRenderedChildComponentId('MiXY2hl');
    $componentTag = $_instance->getRenderedChildComponentTagName('MiXY2hl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MiXY2hl');
} else {
    $response = \Livewire\Livewire::mount('pcategory-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('MiXY2hl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/pcategory/show.blade.php ENDPATH**/ ?>