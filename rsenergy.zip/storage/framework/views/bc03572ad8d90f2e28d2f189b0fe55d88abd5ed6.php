

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card card-body mt-4">
                <div class="row">
                    <h4 class="text-center txet-italic">Add New Project</h4>
                    <hr>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('project.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-3 mb-3">
                        <div class="col-md-6">
                            <label for="name">Project Name</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name">
                        </div>
                    <div class="col-md-6">
                        <label for="customer_id">Select Customer</label>
                        <select name="customer_id" class="form-control">
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                </div>
                <div class="row mt-3 mb-3">
                <div class="col-md-6">
                        <label for="start_date">Start date</label>
                        <input type="date" class="form-control" name="start_date">
                    </div>
                    <div class="col-md-6">
                        <label for="end_date">End Date</label>
                        <input type="date" class="form-control" name="end_date">
                    </div>
                    
                </div>
                <div class="row mt-3 mb-3">
                <div class="col-md-6">
                        <label for="total_kw">Total KW</label>
                        <input type="text" class="form-control" name="total_kw">
                    </div>
                    <div class="col-md-6">
                        <label for="est_price">Estimated Price</label>
                        <input type="text" class="form-control" name="est_price">
                    </div>
                </div>
                <div class="row mt-3">
                    <button class="btn btn-success text-white" type="submit">Add Project</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/project/add.blade.php ENDPATH**/ ?>