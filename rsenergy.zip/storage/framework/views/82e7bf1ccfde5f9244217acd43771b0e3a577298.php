

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <form action="<?php echo e(route('category.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="text-center">
                    <b class="text-italic ">Add new category</b>
                    <hr>
                    </div>
                    <div class="row mt-4">
                        <div class="mb-3">
                            <label for="name">Title</label>
                            <input class="form-control" name="title" type="text">
                        </div>
                    </div>
                        <button class="btn btn-success text-white " type="submit">Save Category</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/category/add.blade.php ENDPATH**/ ?>