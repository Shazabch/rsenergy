
<?php $__env->startSection('content'); ?>
<div class="card card-body mt-4">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-table', [])->html();
} elseif ($_instance->childHasBeenRendered('LKRgTRX')) {
    $componentId = $_instance->getRenderedChildComponentId('LKRgTRX');
    $componentTag = $_instance->getRenderedChildComponentTagName('LKRgTRX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LKRgTRX');
} else {
    $response = \Livewire\Livewire::mount('product-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('LKRgTRX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/product/show.blade.php ENDPATH**/ ?>