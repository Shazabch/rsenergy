

<?php $__env->startSection('content'); ?>
    <div class="card card-body mt-4">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-table', [])->html();
} elseif ($_instance->childHasBeenRendered('jn2eJgI')) {
    $componentId = $_instance->getRenderedChildComponentId('jn2eJgI');
    $componentTag = $_instance->getRenderedChildComponentTagName('jn2eJgI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jn2eJgI');
} else {
    $response = \Livewire\Livewire::mount('payment-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('jn2eJgI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/payment/show.blade.php ENDPATH**/ ?>