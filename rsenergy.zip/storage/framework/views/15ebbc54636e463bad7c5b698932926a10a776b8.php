
<?php $__env->startSection('content'); ?>
<div class="card card-body mt-4">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('purchase-table', [])->html();
} elseif ($_instance->childHasBeenRendered('qNKbm7C')) {
    $componentId = $_instance->getRenderedChildComponentId('qNKbm7C');
    $componentTag = $_instance->getRenderedChildComponentTagName('qNKbm7C');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qNKbm7C');
} else {
    $response = \Livewire\Livewire::mount('purchase-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('qNKbm7C', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/purchase/show.blade.php ENDPATH**/ ?>