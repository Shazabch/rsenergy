
<?php $__env->startSection('content'); ?>
<div class="card card-body mt-4">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-table', [])->html();
} elseif ($_instance->childHasBeenRendered('NBQvw2o')) {
    $componentId = $_instance->getRenderedChildComponentId('NBQvw2o');
    $componentTag = $_instance->getRenderedChildComponentTagName('NBQvw2o');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NBQvw2o');
} else {
    $response = \Livewire\Livewire::mount('customer-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('NBQvw2o', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\rsenergy\resources\views/customer/show.blade.php ENDPATH**/ ?>