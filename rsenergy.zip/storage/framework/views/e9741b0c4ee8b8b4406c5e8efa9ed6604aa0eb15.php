<div class="d-flex align-items-center" style="padding-left: 10px;">
    <div wire:loading class="spinner-border" role="status" style="color: #656363;">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<?php /**PATH E:\projects\rsenergy\resources\views/vendor/livewire-powergrid/components/frameworks/bootstrap5/loading.blade.php ENDPATH**/ ?>